import React from 'react';

export default function notFound()
{
    return (
        <>
        <div className="p-15">
            <h1>No hay nada, busque en otro lado</h1>
        </div>
        <div>
            mire la url esta mal, logout
        </div>
        </>
    )
}