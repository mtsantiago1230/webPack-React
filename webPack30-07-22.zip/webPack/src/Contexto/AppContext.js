import {createContext} from 'react';

const AppContext = createContext();

console.log("se crea contexto",AppContext);

export default AppContext;